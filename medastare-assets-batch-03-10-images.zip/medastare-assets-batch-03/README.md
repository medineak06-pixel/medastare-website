# MedaStaré • Website Assets — Batch 03

This batch contains **10 distinct campaign images**.

- `webp/` — optimized ready-to-use website images (recommended for GitHub/site development).
- `originals/` — original uploaded JPEG files, renamed without modifying image quality.
- `assets-manifest.csv` — mapping of names, source filenames, descriptions, and sizes.

These are static image files. Animated effects and website placement require implementation in the website code.

Example usage: `public/assets/medastare/medastare-ivory-futurist-couture.webp`.

**Note:** This archive is prepared for uploading; it has not been pushed to GitHub.
