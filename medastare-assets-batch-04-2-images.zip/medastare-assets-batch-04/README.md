# MedaStaré – Visual Assets / Batch 04

2 editorial images, individually named.

- `webp/` – Optimized images for the website.
- `originals/` – Original JPEG images retained without alteration.
- `assets-manifest.csv` – Filenames, descriptions, resolutions and sizes.

Upload `webp/` to your website asset directory. This archive does not modify any website code.
