# MedaStaré – Website Assets / Batch 02

Bu pakette 10 görsel bulunmaktadır.

- `webp/`: Web sitesi için optimize edilmiş ve anlamlı adlar verilmiş `.webp` görseller.
- `originals/`: Aynı görsellerin orijinal JPEG verileri (yeniden sıkıştırılmadan).
- `assets-manifest.csv`: Dosya adları, kategorileri, açıklamaları ve boyutları.

GitHub’a web için yalnızca `webp/` dosyalarını yüklemek yeterli olabilir. Kodun önerilen yolu: `public/images/medastare/`.

Not: Bu dosyalar tek tek GitHub'a yüklenmedi; kullanıcı kendi yükleyecektir.
