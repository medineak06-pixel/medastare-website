# MedaStaré Website Assets

10 design images received 10 Oct 2026, renamed and categorized.

- `assets/`: WebP versions optimized for website use, full uploaded pixel dimensions preserved.
- `originals/`: Copies of the supplied JPEG files, content unchanged.
- `assets-manifest.json` and `.csv`: filenames, original upload mapping, dimensions and SHA-256 checksums.

Suggested usage: the web images are not assigned to specific homepage modules yet; those choices will be made after reviewing the website structure.

No live website code was changed. No repository publication is implied by this archive.
